# Awesome Product Management [![Awesome](https://cdn.rawgit.com/sindresorhus/awesome/d7305f38d29fed78fa85652e3a63e154dd8e8829/media/badge.svg)](https://github.com/sindresorhus/awesome)

This Awesome list about [Product Management](https://en.wikipedia.org/wiki/Product_management)  interesting and useful topics. <br /><br />
![PM Banner](https://github.com/shahedbd/awesome-project-management/blob/master/ProductManagement/Resource/pm-main.png)

## Table of Contents
1. [Common](#Common)


## Common
1. [Startup School](https://www.startupschool.org/)
1. [Product Manager HQ](https://www.productmanagerhq.com/)
1. [Resources For New PMs](https://miketadlock.tumblr.com/post/44814775687/resources-for-new-pms)
1. [How to create a product roadmap: step-by-step guide and free template for founders](https://krit.com/blog/product-roadmap-free-template-and-guide-for-founders)
1. [Product Feature UX plan](https://paper.dropbox.com/published/Product-Feature-UX-plan-aTB1elcLy3DC8NwAc33S3Dp)
  


License
----

MIT
